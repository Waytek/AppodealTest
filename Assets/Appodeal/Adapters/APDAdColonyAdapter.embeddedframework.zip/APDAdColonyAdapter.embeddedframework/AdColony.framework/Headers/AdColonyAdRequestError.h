#import "AdColonyTypes.h"

@interface AdColonyAdRequestError : NSError
@end
